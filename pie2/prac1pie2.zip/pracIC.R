################
# Exercici 3.1 #
################
x = c(58, 50, 60, 65, 64, 62, 56, 57)
xbar = mean(x)
n = length(x)
alpha = 0.05

# a)
sd = 3
xbar + c(-1,1)*qnorm(alpha/2, lower.tail = FALSE)*sd/sqrt(n)
# b)
s = sd(x)
xbar + c(-1,1)*qt(alpha/2, n-1, lower.tail = FALSE)*s/sqrt(n)
# c)
(n-1)*var(x)/qchisq(alpha/2, n-1, lower.tail = FALSE)
(n-1)*var(x)/qchisq(1-alpha/2, n-1, lower.tail = FALSE)
# d)
t.test(x)
# install.packages("DescTools")
library(DescTools)
VarCI(x, method = "classic")

################
# Exercici 3.2 #
################
n = 10
alpha = 0.1
Smu = 12.4
n*Smu/qchisq(alpha/2, n, lower.tail = FALSE)
n*Smu/qchisq(1-alpha/2, n, lower.tail = FALSE)

################
# Exercici 3.5 #
################
n = 235
y = 28
phat = y/n
phat + c(-1, 1)*qnorm(alpha/2, lower.tail = FALSE)*sqrt(phat*(1-phat)/n)

################
# Exercici 3.7 #
################
n = 10
xbar = 4.92
alpha = 0.05

s2 = 0.5*qchisq(alpha/2, n-1, lower.tail = FALSE)/(n-1)
xbar+c(-1,1)*qnorm(alpha/2, lower.tail = FALSE)*sqrt(s2)/n
